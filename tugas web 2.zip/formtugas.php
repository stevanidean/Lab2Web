<?php
// mendefinisikan variabel dan diset kosong
$nama = $jekel = $pekerjaan = $asalKota = $alamat = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
 $nama = $_POST["nama"];
 $jekel = $_POST["jenis_kelamin"];
 @$pekerjaan = $_POST["pekerjaan"];
 @$asalKota = $_POST["asal_kota"];
 $alamat = $_POST['alamat'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
 <meta charset="UTF-8">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <title>Form 3</title>
</head>
<body>
 <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"
method="POST">
 <table align="center" cellspacing="0" cellpadding="5"
bordercolor="black">
 <tr>
 <th colspan="3"><u>FORM 1 : INPUT DATA</u></th>
 </tr>
 <tr>
 <td>Nama</td>
 <td>:</td>
 <td><input type="text" name="nama" placeholder="Nama Anda"
/></td>
 </tr>
 <tr>
 <td>Jenis Kelamin</td>
 <td>:</td>
 <td>
 <input type="radio" name="jenis_kelamin" value="laki-laki" required />Laki - Laki
 <input type="radio" name="jenis_kelamin"
value="perempuan" /> Perempuan
 </td>
 </tr>
 <tr>
 <td>Asal Kota</td>
 <td>:</td>
 <td><select name="asal_kota">
 <option selected disabled>Pilih Pekerjaan...</option>
 <option value="teknisi musik">Sound Engineer</option>
 <option value="produser">Producer</option>
 <option value="penulis lagu">writer song</option>
 </select></td>
 </tr>
 <tr>
 <td>Asal Kota</td>
 <td>:</td>
 <td><select name="asal_kota">
 <option selected disabled>Pilih Kota...</option>
 <option value="Kota Jakarta">Jakarta</option>
 <option value="Kota Bandung">Bandung</option>
 <option value="Kota Bekasi">Bekasi</option>
 </select></td>
 </tr>
 <tr>
 <td>Alamat</td>
 <td>:</td>
 <td>
 <textarea class="form-control" rows="5" cols="40"
id="comment" name="alamat"></textarea>
 </td>
 </tr>
 <tr>
 <th colspan="3">
 <input type="submit" value="Simpan">
 <input type="reset" value="Reset">
 </th>
 </tr>
 </table>
 </form>
<?php
echo "<br>";
echo "<br>";
echo "<hr>";
echo "<br>";
echo "Nama Anda adalah : " . $nama ;
echo "<br>";
echo "Jenis Kelamin Anda adalah : " . $jekel ;
echo "<br>";
echo "Pekerjaan Anda adalah : " . $pekerjaan ;
echo "<br>";
echo "Asal Kota Anda adalah : " . $asalKota ;
echo "<br>";
echo "Alamat Anda adalah : " . $alamat ;
echo "<br>";

?>

</body>
</html>